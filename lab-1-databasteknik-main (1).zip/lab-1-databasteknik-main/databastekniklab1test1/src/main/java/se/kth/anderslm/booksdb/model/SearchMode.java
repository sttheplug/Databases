package se.kth.anderslm.booksdb.model;

public enum SearchMode {
    Title, ISBN, Author
}
