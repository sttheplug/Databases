package se.kth.anderslm.booksdb.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.LinkedList;
import java.sql.*;
import java.sql.Connection;


/**
 * Representation of a book.
 *
 * @author anderslm@kth.se
 */
public class Book {

    private int bookId;
    private String isbn; // should check format
    private String title;
    private Date published;
    private String storyLine = "";

    private ArrayList<Score> score;
    private Genre genre;

    private ArrayList<Review> reviews;

    private LinkedList<Author> authors;
    // TODO:
    // Add authors, as a separate class(!), and corresponding methods, to your implementation
    // as well, i.e. "private ArrayList<Author> authors;"

    public Book(int bookId, String isbn, String title, Date published,Genre genre, Score score) {
        this.bookId = bookId;
        this.isbn = isbn;
        this.title = title;
        this.published = published;
        this.authors = new LinkedList<>();
        this.genre = genre;
        this.score = new ArrayList<>();
        this.reviews = new ArrayList<>();

    }

    public Book(String isbn, String title, Date published, Score score, Genre genre) {
        this(-1, isbn, title, published,genre,score);
    }

    public int getBookId() { return bookId; }
    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public Date getPublished() { return published; }
    public String getStoryLine() { return storyLine; }

    public void setStoryLine(String storyLine) {
        this.storyLine = storyLine;
    }

    public Genre getGenre() {
        return genre;
    }

    public int getScore() {
        int calculatedAverageScore = 0;
        int i = 0;
        for(Score s: score)
        {
            calculatedAverageScore += s.ordinal();
            i++;
        }
        calculatedAverageScore = calculatedAverageScore/i;
        return calculatedAverageScore;
    }

    public LinkedList<Author> getAuthors() {
        return (LinkedList<Author>) authors.clone();
    }

    @Override
    public String toString() {
        return title + ", " + isbn + ", " + published.toString() + " " + authors.toString();
    }
}
