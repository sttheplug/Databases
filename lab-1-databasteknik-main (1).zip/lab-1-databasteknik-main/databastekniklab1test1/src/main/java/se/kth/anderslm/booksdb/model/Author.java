package se.kth.anderslm.booksdb.model;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

public class Author {
    private String name;
    private Date dateOfBirth;
    private int authorId;
    private ArrayList<String> languages;

    private ArrayList<Book> titles;

    public Author(String name, Date dateOfBirth, int authorId)
    {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.authorId = authorId;
        this.languages = new ArrayList<>();
        this.titles = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public ArrayList<Book> getTitles() {

        return (ArrayList<Book>) titles.clone();
    }

    public ArrayList<String> getLanguages() {
        return (ArrayList<String>) languages.clone();
    }

    public int getAuthorId() {
        return authorId;
    }

    @Override
    public String toString() {
        String info = "Author: " + name + ", Id: " + authorId + ", Born: " + dateOfBirth +", Written Languages: " + languages.toString() + ", Author of following titles: " + titles.toString();
        return info;
    }
}
