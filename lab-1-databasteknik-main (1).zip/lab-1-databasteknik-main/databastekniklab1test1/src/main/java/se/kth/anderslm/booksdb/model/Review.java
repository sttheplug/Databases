package se.kth.anderslm.booksdb.model;

public class Review {

    private User reviewer;

    private String text;

    private int reviewId;

    public Review(User reviewer, String text, int reviewId)
    {
        this.reviewer = reviewer;
        this.text = text;
        this.reviewId = reviewId;
    }

    public String getText() {
        return text;
    }

    public User getReviewer() {
        return reviewer;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setReviewer(User reviewer) {
        this.reviewer = reviewer;
    }

    public int getReviewId() {
        return reviewId;
    }

    public void setReviewId(int reviewId) {
        this.reviewId = reviewId;
    }
}
