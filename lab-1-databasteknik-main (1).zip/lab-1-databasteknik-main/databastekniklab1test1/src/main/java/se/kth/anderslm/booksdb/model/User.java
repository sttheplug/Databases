package se.kth.anderslm.booksdb.model;

import java.time.LocalDate;

public class User {
    private String name;
    private String password;
    private LocalDate dateOfBirth;
    private String city;
    private String emailAddress;

    // Constructors, getters, setters, and other methods can be added here

    public User(String name, String password, LocalDate dateOfBirth, String city, String emailAddress) {
        this.name = name;
        this.password = password;
        this.dateOfBirth = dateOfBirth;
        this.city = city;
        this.emailAddress = emailAddress;
    }

    // Add getters and setters for each attribute

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
}
