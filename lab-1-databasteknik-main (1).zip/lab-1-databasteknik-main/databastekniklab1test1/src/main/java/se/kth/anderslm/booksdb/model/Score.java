package se.kth.anderslm.booksdb.model;

public enum Score {
    ONE,TWO,THREE,FOUR,FIVE,BESTSELLER;
}
